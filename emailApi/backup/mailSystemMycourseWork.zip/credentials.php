<?php
    define('gEmail', 'ri9606404@gmail.com');
    define('gPass', 'rizwan9606404');
?>